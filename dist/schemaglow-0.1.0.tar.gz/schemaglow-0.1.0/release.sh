#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:?Usage: ./release.sh <version>}"

echo "=== SchemaGlow Release v${VERSION} ==="

ruff format --check .
ruff check .
mypy src
python -m pytest -v
pip-audit

python -m build
python -m twine check dist/*

echo "Update pyproject.toml version manually before tagging."
echo "Suggested next steps:"
echo "  git add pyproject.toml README.md"
echo "  git commit -m \"release: v${VERSION}\""
echo "  git tag \"v${VERSION}\""
